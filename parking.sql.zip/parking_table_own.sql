
-- --------------------------------------------------------

--
-- Структура таблицы `own`
--

CREATE TABLE `own` (
  `phone` int(11) NOT NULL,
  `gov_number` char(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `own`
--

INSERT INTO `own` (`phone`, `gov_number`) VALUES
(123456, 'К312РМ'),
(123456, 'Н404НН'),
(152451, 'А222АА'),
(147852369, 'A001AA');
