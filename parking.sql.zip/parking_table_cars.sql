
-- --------------------------------------------------------

--
-- Структура таблицы `cars`
--

CREATE TABLE `cars` (
  `mark` char(15) NOT NULL,
  `model` char(30) NOT NULL,
  `color` char(15) NOT NULL,
  `gov_number` char(6) NOT NULL,
  `on_parking` tinyint(1) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `cars`
--

INSERT INTO `cars` (`mark`, `model`, `color`, `gov_number`, `on_parking`) VALUES
('BMW', 'X5', 'Серый', 'A001AA', 1),
('Opela', 'Astra', 'Зелёный', 'А222АА', 0),
('Lada', '2112', 'Чёрный', 'К312РМ', 1),
('Lada', '2107', 'Белый', 'Н404НН', 0);
