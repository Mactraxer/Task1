
--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `cars`
--
ALTER TABLE `cars`
  ADD PRIMARY KEY (`gov_number`);

--
-- Индексы таблицы `client`
--
ALTER TABLE `client`
  ADD PRIMARY KEY (`phone`);

--
-- Индексы таблицы `own`
--
ALTER TABLE `own`
  ADD PRIMARY KEY (`gov_number`),
  ADD KEY `phone` (`phone`);

--
-- Ограничения внешнего ключа сохраненных таблиц
--

--
-- Ограничения внешнего ключа таблицы `own`
--
ALTER TABLE `own`
  ADD CONSTRAINT `own_ibfk_1` FOREIGN KEY (`gov_number`) REFERENCES `cars` (`gov_number`) ON UPDATE CASCADE,
  ADD CONSTRAINT `own_ibfk_2` FOREIGN KEY (`phone`) REFERENCES `client` (`phone`) ON UPDATE CASCADE;
