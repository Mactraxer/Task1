
-- --------------------------------------------------------

--
-- Структура таблицы `client`
--

CREATE TABLE `client` (
  `second_name` char(30) NOT NULL,
  `first_name` char(30) NOT NULL,
  `patronymic` char(30) DEFAULT NULL,
  `gender` char(7) NOT NULL,
  `phone` int(11) NOT NULL,
  `adres` char(60) DEFAULT NULL,
  `car` int(100) NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Дамп данных таблицы `client`
--

INSERT INTO `client` (`second_name`, `first_name`, `patronymic`, `gender`, `phone`, `adres`, `car`) VALUES
('Петрова', 'Лилияя', 'Владимировна', 'Женский', 123456, 'ул. Ильича 10', 2),
('Иванов', 'Иван', 'Иванович', 'Мужской', 152451, 'пр. Ленина 17', 1),
('Андропов', 'Илья', 'Викторович', 'Мужской', 147852369, 'ул. Мира 10', 1);
